export default {
  brandId: 'brand id',
  name: 'name',
  desc: 'describe',
  imgUrl: 'logo',
  firstLetter: 'first letter',
  seq: 'seqencing',
  status: 'status'
}
