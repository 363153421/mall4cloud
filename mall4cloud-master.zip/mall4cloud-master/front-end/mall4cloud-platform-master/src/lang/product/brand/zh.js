export default {
  brandId: 'brand_id',
  name: '品牌名称',
  desc: '品牌描述',
  imgUrl: '品牌logo',
  firstLetter: '检索首字母',
  seq: '排序',
  status: '状态'
}
