<template>
  <div class="mod-pay">
    <domain ref="domain" />
  </div>
</template>
<script>
import domain from './domain-config.vue'
export default {
  components: {
    domain
  },
  data() {
    return {
    }
  },
  methods: {

  }
}
</script>
<style lang="scss">
</style>

