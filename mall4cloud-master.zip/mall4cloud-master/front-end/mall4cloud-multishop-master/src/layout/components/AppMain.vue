<template>
  <section class="app-main">
    <transition name="fade-transform" mode="out-in">
      <keep-alive :include="cachedViews">
        <router-view :key="key" />
      </keep-alive>
    </transition>
  </section>
</template>

<script>
export default {
  name: 'AppMain',
  computed: {
    cachedViews() {
      return this.$store.state.tagsView.cachedViews
    },
    key() {
      return this.$route.path
    }
  }
}
</script>

<style lang="scss" scoped>
.app-main {
  position: relative;
  width: 1034px;
  background: #FFFFFF;
  overflow: hidden;
  margin-left: 20px;
}

.hasTagsView {
  .app-main {
    /* 134 = navbar + tags-view + margin-bottom = 94 + 20 + 20 */
    min-height: calc(100vh - 134px);
  }
}
</style>

<style lang="scss">
// fix css style bug in open el-dialog
.el-popup-parent--hidden {
  .fixed-header {
    padding-right: 15px;
  }
}
</style>
