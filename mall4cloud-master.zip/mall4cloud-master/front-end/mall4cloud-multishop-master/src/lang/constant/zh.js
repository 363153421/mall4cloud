export default {
  noNull: '不能为空',
  product: '商品',
  shop: '店铺',
  contactName: '联系人',
  contactTel: '联系电话',
  consignee: '收货人',
  mobilePhone: '手机号码',
  deliveryAddr: '收货地址',
  name: '名称',
  dollar: '元',
  piece: '件',
  normal: '正常'
}
