export default {
  carouselImg: '轮播图片',
  recommImgSize: '建议图片尺寸为',
  carouselImgNoNull: '轮播图片不能为空',
  sortNONull: '排序值不能为空',
  weChatPay: '微信支付',
  aliPay: '支付宝支付',
  balancePay: '余额支付',
  add: '添加',
  remove: '移除',
  dollar: '元'
}
