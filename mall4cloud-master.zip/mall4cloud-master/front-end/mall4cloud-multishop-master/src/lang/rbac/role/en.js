export default {
  roleId: 'role id',
  roleName: 'role name',
  remark: 'remark',
  createUserId: 'create user id',
  bizType: 'biz type',
  tenantId: 'tenant id'
}
