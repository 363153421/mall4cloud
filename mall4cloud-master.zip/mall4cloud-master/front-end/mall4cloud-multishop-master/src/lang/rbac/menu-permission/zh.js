export default {
  menuPermissionId: '菜单资源用户id',
  menuTitle: '资源关联菜单',
  bizType: '业务类型 0平台菜单 1 店铺菜单',
  permission: '权限对应的编码',
  name: '资源名称',
  uri: '资源对应服务器路径',
  method: '请求方法'
}
