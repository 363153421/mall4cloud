export default {
  menuPermissionId: 'menu permission id',
  menuTitle: 'menu title',
  bizType: 'biz type',
  permission: 'permission',
  name: 'name',
  uri: 'uri',
  method: 'method'
}
