export default {
  spuId: 'spu id',
  brandId: '品牌ID',
  categoryId: '分类ID',
  name: 'spu名称',
  sellingPoint: '卖点',
  imgUrls: '商品介绍主图',
  priceFee: '售价',
  priceScale: '售价',
  marketPriceFee: '市场价',
  marketPriceScale: '市场价',
  status: '状态'
}
