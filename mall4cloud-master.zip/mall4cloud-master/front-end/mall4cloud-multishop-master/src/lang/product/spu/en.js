export default {
  spuId: 'spu id',
  brandId: 'brand id',
  categoryId: 'category id',
  name: 'name',
  sellingPoint: 'selling point',
  imgUrls: 'img urls',
  priceFee: 'price fee',
  priceScale: 'price scale',
  marketPriceFee: 'market price fee',
  marketPriceScale: 'market price scale',
  status: 'status'
}
