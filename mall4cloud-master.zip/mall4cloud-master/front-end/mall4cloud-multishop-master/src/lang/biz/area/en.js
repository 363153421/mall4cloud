export default {
  areaId: 'area id',
  areaName: 'area name',
  parentId: 'parent id',
  level: 'level'
}
