export default {
  shopUserId: '商家用户id',
  shopId: '关联店铺id',
  nickName: '昵称',
  avatar: '头像',
  code: '员工编号',
  phoneNum: '联系方式',
  hasAccount: '是否已经设置账号'
}
