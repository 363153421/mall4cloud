export default {
  hotSearchId: 'hot search id',
  shopId: 'shop id',
  content: 'content',
  createDate: 'create date',
  seq: 'seq',
  status: 'status',
  title: 'title'
}
