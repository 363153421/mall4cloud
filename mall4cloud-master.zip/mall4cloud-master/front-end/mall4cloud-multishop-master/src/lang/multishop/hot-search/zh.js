export default {
  hotSearchId: '主键',
  shopId: '店铺ID',
  content: '热搜内容',
  createDate: '创建时间',
  seq: '顺序',
  status: '状态',
  title: '热搜标题'
}
