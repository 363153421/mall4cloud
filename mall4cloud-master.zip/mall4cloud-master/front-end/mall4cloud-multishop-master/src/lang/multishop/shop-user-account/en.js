export default {
  email: 'email',
  phone: 'phone',
  username: 'username',
  password: 'password',
  status: 'status'
}
