export default {
  email: '邮箱',
  phone: '手机号',
  username: '用户名',
  password: '密码',
  status: '状态'
}
