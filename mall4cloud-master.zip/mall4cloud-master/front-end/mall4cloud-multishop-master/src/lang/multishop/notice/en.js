export default {
  id: 'id',
  shopId: 'shop id',
  title: 'title',
  content: 'content',
  type: 'type',
  status: 'status',
  isTop: 'is top',
  publishTime: 'publish time'
}
