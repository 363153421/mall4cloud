export default {
  categorySelector: '分类选择器',
  chooseProdCateg: '选择商品分类',
  currCho: '你当前的选择是',
  isItAComtionPro: '是否为组合商品',
  generalMerchandise: '普通商品',
  combinationGoods: '组合商品',
  haveReadFol: '确认选择'
}
