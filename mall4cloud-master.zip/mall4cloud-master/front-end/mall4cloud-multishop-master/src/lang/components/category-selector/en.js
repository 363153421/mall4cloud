export default {
  categorySelector: 'Category selector',
  chooseProdCateg: 'Select product category',
  currCho: 'Your current choice is',
  isItAComtionPro: 'Is it a combination product ',
  generalMerchandise: 'General Product',
  combinationGoods: 'Combined product',
  haveReadFol: 'Confirm selection'
}
