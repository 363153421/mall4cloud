export default {
  contactTel: '联系电话',
  phone: '电话'
}
