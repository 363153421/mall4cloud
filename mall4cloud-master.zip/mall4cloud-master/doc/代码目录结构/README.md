`mall4cloud`是一个前后端分离的项目，所以由多个项目组成，如下：

- `mall4cloud` : java微服务后台代码（包含后台、前端、所有微服务相关的接口）
- `mall4cloud-multishop` : 商家端vue代码
- `mall4cloud-platform` : 平台端vue代码
- `mall4cloud-uniapp` :  移动端uniapp代码（包含 H5、小程序、android、ios）
